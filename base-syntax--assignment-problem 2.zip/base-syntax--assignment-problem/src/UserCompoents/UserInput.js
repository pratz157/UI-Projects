import React, { Component } from 'react';
import './User.css'

class UserInput extends Component{

    
    render(){
        return(
            <div>
                <p>Username : &nbsp; 
                    <input className='userNameStyle' type="text" onChange={this.props.changedUserName} value={this.props.userName}/>
                </p>
            </div>
        )
    }
}

export default UserInput;